<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_title</name>
   <tag></tag>
   <elementGuidId>8975065a-b14d-4167-9792-78b0f9a75a59</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-job-detail-page[1]/div[@class=&quot;container&quot;]/div[@class=&quot;row container-fluid&quot;]/div[@class=&quot;col-md-8&quot;]/app-job-content-header-view[1]/div[@class=&quot;row col-md-12&quot;]/div[@class=&quot;col-md-10 div-padding text-center&quot;]/h3[@class=&quot;job-title mb-0 purple-color&quot;]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Automation and Manual Tester</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>job-title mb-0 purple-color</value>
   </webElementProperties>
</WebElementEntity>
