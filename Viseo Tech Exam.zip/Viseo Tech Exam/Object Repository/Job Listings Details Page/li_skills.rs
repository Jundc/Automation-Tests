<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_skills</name>
   <tag></tag>
   <elementGuidId>b9ae70da-601d-41ca-9a31-63f95fa96a06</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-job-detail-page[1]/div[@class=&quot;container&quot;]/div[@class=&quot;row container-fluid&quot;]/div[@class=&quot;col-md-8&quot;]/app-job-content-view[1]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/dl[1]/dd[1]/ul[@class=&quot;item&quot;]/li[1]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>javascript testing</value>
   </webElementProperties>
</WebElementEntity>
