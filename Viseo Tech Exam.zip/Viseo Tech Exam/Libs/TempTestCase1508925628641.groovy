import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.logging.KeywordLogger
import groovy.lang.MissingPropertyException
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.webui.contribution.WebUiDriverCleaner
import com.kms.katalon.core.mobile.contribution.MobileDriverCleaner


DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())


RunConfiguration.setExecutionSettingFile('C:\\Users\\hongkong\\AppData\\Local\\Temp\\Katalon\\Test Cases\\WeLinkTalent\\20171025_180028\\execution.properties')

TestCaseMain.beforeStart()
try {
    
        TestCaseMain.runTestCaseRawScript(
'''import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

not_run: WebUI.openBrowser('')

'open WeLinkTalent site'
not_run: WebUI.navigateToUrl(GlobalVariable.URL)

'Click Home link'
not_run: WebUI.verifyElementPresent(findTestObject('Home Page/h5_Home'), 0)

not_run: WebUI.click(findTestObject('Home Page/h5_Home'))

'Enter Log-in details'
not_run: WebUI.setText(findTestObject('Log In Page/input_username'), GlobalVariable.Username)

not_run: WebUI.setText(findTestObject('Log In Page/input_password'), GlobalVariable.Password)

'Click Sign In button'
not_run: WebUI.verifyElementPresent(findTestObject('Log In Page/button_Sign in'), 0)

not_run: WebUI.click(findTestObject('Log In Page/button_Sign in'))

'Click Create Job button'
not_run: WebUI.verifyElementPresent(findTestObject('Create Job Page/button_Create a Job'), 0)

not_run: WebUI.click(findTestObject('Create Job Page/button_Create a Job'))

'Populate and select field values'
not_run: WebUI.setText(findTestObject('Create Job Details Page/input_title'), Job_Title)

not_run: WebUI.setText(findTestObject('Create Job Details Page/input_industry'), Industry)

not_run: WebUI.selectOptionByValue(findTestObject('Create Job Details Page/select_job_type'), Job_Type, true)

not_run: WebUI.selectOptionByValue(findTestObject('Create Job Details Page/select_employment_type'), Employment_Type, true)

not_run: WebUI.setText(findTestObject('Create Job Details Page/input_expertise'), Expertise)

not_run: WebUI.setText(findTestObject('Create Job Details Page/input_years_experience'), Years_of_Experience)

not_run: WebUI.setText(findTestObject('Create Job Details Page/input_application_slots'), Vacant_Slots)

not_run: WebUI.check(findTestObject('Create Job Details Page/input_salary_negotiable'))

not_run: WebUI.selectOptionByValue(findTestObject('Create Job Details Page/select_salary_currency (1)'), 'SGD', true)

not_run: WebUI.setText(findTestObject('Create Job Details Page/input_salary_from'), Salary_From)

not_run: WebUI.setText(findTestObject('Create Job Details Page/input_salary_to'), Salary_to)

not_run: WebUI.setText(findTestObject('Create Job Details Page/input_skill'), Required_Skills)

not_run: WebUI.setText(findTestObject('Create Job Details Page/input_responsibility'), Responsibilities)

not_run: WebUI.setText(findTestObject('Create Job Details Page/input_talent'), Ideal_Talent)

not_run: WebUI.setText(findTestObject('Create Job Details Page/textarea_form-control ng-untou'), Job_Description)

not_run: WebUI.setText(findTestObject('Create Job Details Page/input_name'), Company)

not_run: WebUI.setText(findTestObject('Create Job Details Page/input_address'), Address)

not_run: WebUI.setText(findTestObject('Create Job Details Page/input_i (2)'), Phone)

not_run: WebUI.setText(findTestObject('Create Job Details Page/input_form-control ng-dirty ng'), Email)

not_run: WebUI.setText(findTestObject('Create Job Details Page/input_twitter'), Twitter)

not_run: WebUI.setText(findTestObject('Create Job Details Page/input_linkedin'), Linkedin)

not_run: WebUI.setText(findTestObject('Create Job Details Page/textarea_about'), About)

not_run: WebUI.uploadFile(findTestObject('Create Job Details Page/input_form-control'), Browse)

'Click Save button'
not_run: WebUI.verifyElementPresent(findTestObject('Create Job Details Page/button_SAVE'), 0)

not_run: WebUI.click(findTestObject('Create Job Details Page/button_SAVE'))

'Verify Job Posting'
WebUI.verifyElementText(findTestObject('Job Listings Page/h5_title'), Job_Title)

WebUI.verifyElementText(findTestObject('Job Listings Page/h6_company'), Company)

WebUI.verifyElementText(findTestObject('Job Listings Page/p_about'), About)

WebUI.verifyElementText(findTestObject('Job Listings Page/h2_vacancy'), Vacant_Slots)

WebUI.verifyElementText(findTestObject('Job Listings Page/h5_address'), Address)

WebUI.verifyElementText(findTestObject('Job Listings Page/h5_jobtype'), Job_Type)

WebUI.verifyElementText(findTestObject('Job Listings Page/h5_employment'), Employment_Type)

WebUI.verifyElementText(findTestObject('Job Listings Page/h5_from'), 'SGD550')

WebUI.verifyElementText(findTestObject('Job Listings Page/h5_to'), 'SGD750')

'Click Read More button'
WebUI.verifyElementPresent(findTestObject('Job Listings Page/h4_Read More'), 0)

WebUI.click(findTestObject('Job Listings Page/h4_Read More'))

'Verify Job Posting details'
WebUI.verifyElementText(findTestObject('Job Listings Details Page/h3_title'), Job_Title)

WebUI.verifyElementText(findTestObject('Job Listings Details Page/div_job details'), Employment_Type)

WebUI.verifyElementText(findTestObject('Job Listings Details Page/div_job details'), Address)

WebUI.verifyElementText(findTestObject('Job Listings Details Page/div_job details'), Industry)

WebUI.verifyElementText(findTestObject('Job Listings Details Page/div_job details'), Expertise)

WebUI.verifyElementText(findTestObject('Job Listings Details Page/div_job details'), Salary_From)

WebUI.verifyElementText(findTestObject('Job Listings Details Page/div_job details'), Salary_to)

WebUI.verifyElementText(findTestObject('Job Listings Details Page/div_job details'), Company)

WebUI.verifyElementText(findTestObject('Job Listings Details Page/div_job details'), Phone)

WebUI.verifyElementText(findTestObject('Job Listings Details Page/div_job details'), Email)

WebUI.verifyElementText(findTestObject('Job Listings Details Page/p_desc'), Job_Description)

WebUI.verifyElementText(findTestObject('Job Listings Details Page/li_skills'), Required_Skills)

WebUI.verifyElementText(findTestObject('Job Listings Details Page/li_respon'), Responsibilities)

WebUI.verifyElementText(findTestObject('Job Listings Details Page/li_talent'), Ideal_Talent)

WebUI.verifyElementText(findTestObject('Job Listings Details Page/p_about'), About)

WebUI.verifyElementText(findTestObject('Job Listings Details Page/h1_vacancy'), Vacant_Slots)

WebUI.verifyElementPresent(findTestObject('Job Listings Details Page/img_logo'), 0)

WebUI.closeBrowser()

''', 'Test Cases/WeLinkTalent', new TestCaseBinding('Test Cases/WeLinkTalent', [:]), FailureHandling.STOP_ON_FAILURE )
    
} catch (Exception e) {
    TestCaseMain.logError(e, 'Test Cases/WeLinkTalent')
}
