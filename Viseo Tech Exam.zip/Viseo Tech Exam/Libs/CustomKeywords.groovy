

import com.kms.katalon.core.testobject.TestObject

import java.lang.String


def static "newpackage.FileExplorer.uploadFile"(
    	TestObject to	
     , 	String filePath	) {
    (new newpackage.FileExplorer()).uploadFile(
        	to
         , 	filePath)
}
